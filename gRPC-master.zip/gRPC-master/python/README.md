# Google Base Libraries

In this folder the base libraries provided by google should be located.
Download the release asset for your client languange and the gRPC version running on the target device from [github.com/protocolbuffers/protobuf/releases/](https://github.com/protocolbuffers/protobuf/releases/). Copy the ``src/google`` folder from the archive to this folder.